<?php
/**
 * Plugin Name:       Content Comparison Plugin
 * Plugin URI:        https://example.com/plugins/content-comparison/
 * Description:       Provides a powerful content comparison feature for specified post types.
 * Version:           1.0.1  // Version updated
 * Author:            huangao
 * Author URI:        https://example.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       content-comparison-plugin
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

// Define plugin constants
define( 'CCP_VERSION', '1.0.1' ); // Updated version
define( 'CCP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CCP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'CCP_DB_VERSION', '1.0' ); // Used for database schema updates

// Include required files
require_once CCP_PLUGIN_DIR . 'includes/database.php';
require_once CCP_PLUGIN_DIR . 'includes/rewrite-rules.php';
require_once CCP_PLUGIN_DIR . 'includes/ajax-handler.php';
require_once CCP_PLUGIN_DIR . 'includes/helpers.php';
require_once CCP_PLUGIN_DIR . 'admin/settings-page.php';
require_once CCP_PLUGIN_DIR . 'public/shortcode.php';
require_once CCP_PLUGIN_DIR . 'public/comparison-handler.php';

/**
 * Activation hook.
 * Creates database table and flushes rewrite rules.
 */
function ccp_activate() {
    ccp_create_comparison_table();
    ccp_register_rewrite_rules();
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'ccp_activate' );

/**
 * Deactivation hook.
 * Flushes rewrite rules.
 */
function ccp_deactivate() {
    flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'ccp_deactivate' );

/**
 * Load plugin textdomain for translation.
 */
function ccp_load_textdomain() {
    load_plugin_textdomain( 'content-comparison-plugin', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
}
add_action( 'plugins_loaded', 'ccp_load_textdomain' );

/**
 * Enqueue admin scripts and styles.
 */
function ccp_admin_enqueue_scripts( $hook_suffix ) {
    // Only load on our settings page
    if ( 'settings_page_content-comparison-settings' !== $hook_suffix ) {
        return;
    }
    wp_enqueue_style( 'ccp-admin-style', CCP_PLUGIN_URL . 'admin/assets/css/admin-style.css', array(), CCP_VERSION );
    wp_enqueue_script( 'ccp-admin-script', CCP_PLUGIN_URL . 'admin/assets/js/admin-script.js', array( 'jquery' ), CCP_VERSION, true );
    wp_localize_script( 'ccp-admin-script', 'ccp_admin_ajax', array(
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'nonce'    => wp_create_nonce( 'ccp_admin_nonce' ), // Add nonce for potential future admin AJAX
    ));
}
add_action( 'admin_enqueue_scripts', 'ccp_admin_enqueue_scripts' );

/**
 * Register/Enqueue public scripts and styles.
 * Scripts/Styles for the shortcode itself are now enqueued directly within the shortcode function.
 * This function now mainly handles registering assets, loading assets on the comparison results page,
 * and localizing script data.
 */
function ccp_public_enqueue_scripts() {
    global $post; // Keep global $post in case needed by other logic later

    // 1. Register Scripts & Styles (so shortcode can enqueue them by handle)
    //    Handles should be unique.
    wp_register_style( 'ccp-public-style', CCP_PLUGIN_URL . 'public/assets/css/public-style.css', array(), CCP_VERSION );
    // Register jQuery UI default theme CSS. Can be enqueued by shortcode or here if needed.
    wp_register_style( 'jquery-ui-css', '//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css', array(), '1.13.2' ); // Use specific version
    // Note: jQuery and jQuery UI Autocomplete JS are usually registered by WP Core.
    // We list them as dependencies when registering/enqueuing our script.
    wp_register_script( 'ccp-public-script', CCP_PLUGIN_URL . 'public/assets/js/public-script.js', array( 'jquery', 'jquery-ui-autocomplete' ), CCP_VERSION, true );

    // 2. Check if we are on the comparison results page (using the query var)
    $is_comparison_page = (bool) get_query_var( 'comparison_slugs' );

    // 3. Enqueue assets ONLY on the comparison results page from this function
    if ( $is_comparison_page ) {
         wp_enqueue_style( 'ccp-public-style' );
         // Styles from jQuery UI might not be needed on the results page unless you use its widgets there
         // wp_enqueue_style( 'jquery-ui-css' );
         // Enqueue the main JS if it contains logic needed for the comparison results page (e.g., interactive elements)
         // wp_enqueue_script( 'ccp-public-script' );
    }

    // 4. Localize script data for 'ccp-public-script'
    //    This provides the necessary data (AJAX URL, nonce, texts) to our JavaScript.
    //    It should run whenever 'ccp-public-script' *might* be loaded (either by the shortcode or on the results page).
    //    Localizing after registration ensures the data is available if the script is enqueued later.
    wp_localize_script( 'ccp-public-script', 'ccp_ajax', array(
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'nonce'    => wp_create_nonce( 'ccp_search_nonce' ),
        'compare_base_url' => home_url( '/' ), // 修改为根目录
        'texts' => array(
            'select_two' => __( '请选择两个项目进行比较.', 'content-comparison-plugin' ),
            'select_different' => __( '请选择两个不同的项目.', 'content-comparison-plugin' ),
            'error' => __( '发生错误，请重试.', 'content-comparison-plugin' ),
        )
    ));
}
add_action( 'wp_enqueue_scripts', 'ccp_public_enqueue_scripts' );


// Initialize rewrite rules on init
add_action( 'init', 'ccp_register_rewrite_rules' );

// Add query vars
add_filter( 'query_vars', 'ccp_register_query_vars' );

// Template redirect for comparison page
add_filter( 'template_include', 'ccp_template_include' );

// Register AJAX handlers
add_action( 'wp_ajax_ccp_search_posts', 'ccp_ajax_search_posts' );
add_action( 'wp_ajax_nopriv_ccp_search_posts', 'ccp_ajax_search_posts' );

// Register settings page
add_action( 'admin_menu', 'ccp_add_admin_menu' );
add_action( 'admin_init', 'ccp_settings_init' );

// Register shortcodes
add_shortcode( 'compare_selector', 'ccp_compare_selector_shortcode' );
add_shortcode('recent_comparisons', 'ccp_display_recent_comparisons_shortcode');
add_shortcode('popular_comparisons', 'ccp_display_popular_comparisons_shortcode');


/**
 * Adds SEO meta tags (description, keywords, canonical) to the <head>
 * specifically for the comparison page.
 */
/**
 * Adds SEO meta tags (description, keywords, canonical) to the <head>
 * specifically for the comparison page.
 */
function ccp_add_seo_meta_tags() {
    // Only run on the comparison page by checking the query var
    if ( ! get_query_var( 'comparison_slugs' ) ) {
        return;
    }


    // Get the comparison data (contains post1, post2 objects)
    $comparison_data = ccp_get_comparison_data(); // Check this function if data is wrong


    // If data retrieval failed (e.g., invalid slugs, posts not found), do nothing
    if ( ! $comparison_data || ! isset($comparison_data['post1']) || ! isset($comparison_data['post2']) ) {
         error_log('CCP DEBUG [SEO Meta]: Comparison data is invalid or missing post objects.');
        return;
    }

    $post1 = $comparison_data['post1'];
    $post2 = $comparison_data['post2'];


    $post_type = $comparison_data['post_type'];
    $post_type_object = get_post_type_object($post_type);
    $post_type_name = $post_type_object ? $post_type_object->labels->singular_name : $post_type;

    // --- 1. Generate Canonical URL ---
    $slug1 = ccp_get_comparison_slug($post1); // Check this function if slugs are wrong
    $slug2 = ccp_get_comparison_slug($post2);


    if ($slug1 && $slug2) { // Ensure slugs were generated
        // Check if your rewrite rule includes /compare/ or not. Adjust accordingly.
        // Assuming root relative rewrite: ^slug-vs-slug/$
        $canonical_url = home_url( "/{$slug1}-vs-{$slug2}/" );
        // If rewrite rule is ^compare/slug-vs-slug/$ use:
        // $canonical_url = home_url( "/compare/{$slug1}-vs-{$slug2}/" );

        echo '<link rel="canonical" href="' . esc_url( $canonical_url ) . '" />' . "\n"; // Only output ONCE
    } else {
         error_log('CCP DEBUG [SEO Meta]: Failed to generate slugs for canonical URL.');
    }

    // --- 2. Generate Meta Description ---
// 获取对比摘要
$summary = ccp_generate_comparison_summary(
    esc_html($post1->post_title),
    esc_html($post2->post_title),
    ccp_calculate_numeric_differences(
        get_fields($post1->ID),
        get_fields($post2->ID)
    )
);

// 如果摘要太长则截断
if (mb_strlen($summary) > 160) {
    $summary = mb_substr($summary, 0, 157) . '...';
}

echo '<meta name="description" content="' . esc_attr($summary) . '" />' . "\n";

    // --- 3. Generate Meta Keywords (Optional) ---
    $keywords = array(
         esc_html( $post1->post_title ),
         esc_html( $post2->post_title ),
         esc_html( $post_type_name ),
         __('详细参数对比', 'content-comparison-plugin'),
         __('性能差异', 'content-comparison-plugin'),
         __('产品区别', 'content-comparison-plugin'),
    );
    $keywords_string = implode( ', ', array_unique( array_filter( $keywords ) ) );
    if ( ! empty( $keywords_string ) ) {
         echo '<meta name="keywords" content="' . esc_attr( $keywords_string ) . '" />' . "\n";
    }
}
// Note: The add_action('wp_head', 'ccp_add_seo_meta_tags'); hook remains the same.

/**
 * Filters the document title specifically for the comparison page.
 * Uses the 'document_title_parts' filter, requires theme support for 'title-tag'.
 *
 * @param array $title_parts The parts of the document title.
 * @return array Modified title parts.
 */
function ccp_filter_comparison_title( $title_parts ) {
     // Only run on the comparison page
    if ( ! get_query_var( 'comparison_slugs' ) ) {
        return $title_parts; // Return original title parts if not our page
    }

    // Get the comparison data
    $comparison_data = ccp_get_comparison_data();

    // If data retrieval failed, return original title
     if ( ! $comparison_data || ! isset($comparison_data['post1']) || ! isset($comparison_data['post2']) ) {
        return $title_parts;
    }

    $post1 = $comparison_data['post1'];
    $post2 = $comparison_data['post2'];
    $post_type = $comparison_data['post_type'];
    $post_type_object = get_post_type_object($post_type);
    $post_type_name = $post_type_object ? $post_type_object->labels->singular_name : $post_type;

    // Construct the new title
    // Example: "Intel Core i9 vs AMD Ryzen 9 - CPU Comparison"
    $new_title = sprintf(
        // Translators: %1$s is Item 1 Title, %2$s is Item 2 Title, %3$s is Post Type Name. Example: "%1$s vs %2$s - %3$s Comparison"
        __( '%1$s vs %2$s - %3$s Comparison', 'content-comparison-plugin' ),
        esc_html( $post1->post_title ),
        esc_html( $post2->post_title ),
        esc_html( $post_type_name )
    );

    // Replace the main title part
    $title_parts['title'] = $new_title;

    // Optional: Remove tagline from comparison page title if desired
    // unset($title_parts['tagline']);

    return $title_parts;
}


// --- Register the Hooks ---
// Add meta tags to the <head>
add_action( 'wp_head', 'ccp_add_seo_meta_tags' );

// Filter the document title (Requires theme support for 'title-tag')
// add_filter( 'document_title_parts', 'ccp_filter_comparison_title' ); // REMOVE OR COMMENT OUT THIS LINE

/**
 * Starts output buffering early on comparison pages.
 */
function ccp_start_buffer_for_title() {
    // Only buffer on the comparison page
    if ( get_query_var( 'comparison_slugs' ) ) {
        // ob_start() captures all subsequent output into a buffer
        ob_start();
    }
}
// Hook early, after query vars are parsed but before header output typically starts
add_action( 'template_redirect', 'ccp_start_buffer_for_title', 1 );

/**
 * Ends output buffering late, modifies the title tag in the buffer, and echoes result.
 */
function ccp_end_buffer_and_filter_title() {
    // Check if we are on the comparison page AND if output buffering is active
    if ( get_query_var( 'comparison_slugs' ) && ob_get_level() > 0 ) {

        // Get the comparison data AGAIN (needed to build the title)
        // Make sure the data fetching issue identified in Step 1 is resolved first!
         $comparison_data = ccp_get_comparison_data();

         // Get the entire buffered HTML content
         $buffer = ob_get_clean(); // Get buffer content AND stop buffering

        if ( $comparison_data && isset($comparison_data['post1']) && isset($comparison_data['post2']) ) {
            // --- Build the new title string ---
            $post1 = $comparison_data['post1'];
            $post2 = $comparison_data['post2'];
            $post_type = $comparison_data['post_type'];
            $post_type_object = get_post_type_object($post_type);
            $post_type_name = $post_type_object ? $post_type_object->labels->singular_name : $post_type;

            $new_title_content = sprintf(
                __( '%1$s 和 %2$s 参数对比 性能差异和区别 - CPU Rank List', 'content-comparison-plugin' ),
                esc_html( $post1->post_title ),
                esc_html( $post2->post_title ),
                esc_html( $post_type_name )
            );
            // Escape the title content for direct insertion into HTML
            $new_title_escaped = esc_html($new_title_content);

            // --- Replace the title in the buffer ---
            // This regex looks for <title>...</title> and replaces its content.
            // It's case-insensitive (i) and replaces only the first match.
            $buffer = preg_replace( '/<title>(.*?)<\/title>/si', '<title>' . $new_title_escaped . '</title>', $buffer, 1 );

        } else {
            // If data failed, do nothing to the title, just output the original buffer
            error_log('CCP WARNING [Output Buffer]: Could not get comparison data to filter title.');
        }

        // Output the modified (or original if failed) buffer
        echo $buffer;

    } elseif ( ob_get_level() > 0 && !get_query_var( 'comparison_slugs' ) ) {
         // Safety net: If buffering is on but it's not our page, something else started it.
         // It's generally safer *not* to interfere and let the original mechanism finish.
         // OR maybe just flush it? Let's be cautious and do nothing.
         // If necessary, can add: echo ob_get_clean(); to flush other buffers.
    }
}
// Hook very late, after almost all HTML is generated but before final output. 'shutdown' is usually safe.
add_action( 'shutdown', 'ccp_end_buffer_and_filter_title', 0 );

/**
 * Adds standard WordPress rewrite rules for pretty search URLs (/search/keyword/).
 */
function ccp_add_standard_search_rewrite_rules() {
    // Rule for the search results page: /search/keyword/
    add_rewrite_rule(
        '^search/([^/]+)/?$',       // Matches /search/keyword/ (relative to WP root)
        'index.php?s=$matches[1]', // Maps to standard WP search query var 's'
        'top'                      // Priority
    );

    // Rule for paginated search results: /search/keyword/page/N/
    add_rewrite_rule(
        '^search/([^/]+)/page/([0-9]+)/?$', // Matches /search/keyword/page/N/
        'index.php?s=$matches[1]&paged=$matches[2]', // Maps to search query 's' and pagination 'paged'
        'top'                                       // Priority
    );
}
// Hook into 'init' to register the rules
add_action( 'init', 'ccp_add_standard_search_rewrite_rules' );

// Shortcode function for displaying recent comparisons (Example)
function ccp_display_recent_comparisons_shortcode($atts) {
    $atts = shortcode_atts( array(
        'limit' => 5,
        'post_type' => '', // Filter by post type if needed
    ), $atts, 'recent_comparisons' );

    $comparisons = ccp_get_comparisons( 'recent', absint($atts['limit']), sanitize_text_field($atts['post_type']) );
    if ( empty($comparisons) ) {
        return '<p>' . __('No recent comparisons found.', 'content-comparison-plugin') . '</p>';
    }

    $output = '<ul class="ccp-recent-comparisons">';
    foreach ($comparisons as $comp) {
        $post1 = get_post($comp->item1_id);
        $post2 = get_post($comp->item2_id);
        if ($post1 && $post2) {
            $slug1 = ccp_get_comparison_slug($post1);
            $slug2 = ccp_get_comparison_slug($post2);
            if ($slug1 && $slug2) { // Ensure slugs were generated
                $url = home_url("/{$slug1}-vs-{$slug2}/");
                $post_type_obj = get_post_type_object($comp->post_type);
                $post_type_name = $post_type_obj ? $post_type_obj->labels->singular_name : $comp->post_type;
                $output .= sprintf(
                    '<li><a href="%s">%s vs %s</a> <span class="ccp-time-label" title="%s">上次对比 %s</span></li>',
                    esc_url($url),
                    esc_html($post1->post_title),
                    esc_html($post2->post_title),
                    esc_attr(date('Y-m-d H:i:s', strtotime($comp->last_compared))),
                    esc_html(human_time_diff(strtotime($comp->last_compared)) . __('前', 'content-comparison-plugin'))
                );
            }
        }
    }
    $output .= '</ul>';
    return $output;
}

// Shortcode function for displaying popular comparisons (Example)
function ccp_display_popular_comparisons_shortcode($atts) {
    $atts = shortcode_atts( array(
        'limit' => 5,
        'post_type' => '', // Filter by post type if needed
    ), $atts, 'popular_comparisons' );

    $comparisons = ccp_get_comparisons( 'popular', absint($atts['limit']), sanitize_text_field($atts['post_type']) );

     if ( empty($comparisons) ) {
        return '<p>' . __('No popular comparisons found.', 'content-comparison-plugin') . '</p>';
    }

    $output = '<ul class="ccp-popular-comparisons">';
    foreach ($comparisons as $comp) {
        $post1 = get_post($comp->item1_id);
        $post2 = get_post($comp->item2_id);
         if ($post1 && $post2) {
            $slug1 = ccp_get_comparison_slug($post1);
            $slug2 = ccp_get_comparison_slug($post2);
             if ($slug1 && $slug2) { // Ensure slugs were generated
                $url = home_url("/{$slug1}-vs-{$slug2}/");
                $post_type_obj = get_post_type_object($comp->post_type);
                $post_type_name = $post_type_obj ? $post_type_obj->labels->singular_name : $comp->post_type;
                $output .= sprintf(
                    // Translators: %1$s is item 1 title, %2$s is item 2 title, %3$s is post type name, %4$d is comparison count
                    '<li><a href="%s">%s vs %s</a> <span class="ccp-time-label" title="%s">累计对比 %s 次</span></li>',
                    esc_url($url),
                    esc_html($post1->post_title),
                    esc_html($post2->post_title),
                    esc_html($post_type_name),
                    absint($comp->count) // Use absint for count
                );
            }
        }
    }
    $output .= '</ul>';
    return $output;
}

// 添加在文件末尾的函数部分
/**
 * 计算两个产品的数值参数对比差异
 */
function ccp_calculate_numeric_differences($product1_params, $product2_params) {
    $differences = [];
    $excluded_params = ['year', 'release_year', 'launch_date']; // 排除的非数值参数
    
    foreach ($product1_params as $param => $value1) {
        // 跳过非数值参数和排除项
        if (in_array($param, $excluded_params) || !is_numeric($value1)) {
            continue;
        }
        
        $value2 = $product2_params[$param] ?? 0;
        if (!is_numeric($value2)) {
            continue;
        }

        // 计算领先百分比 (保留1位小数)
        $difference = 0;
        if ($value2 != 0) { // 避免除零错误
            $difference = round((($value1 - $value2) / $value2) * 100, 1);
        }
        
        $differences[$param] = $difference;
    }
    
    return $differences;
}

/**
 * 生成对比摘要语句 (仅显示预设映射参数的对比结果)
 */
function ccp_generate_comparison_summary($product1_name, $product2_name, $differences) {
    // 预设需要显示的字段映射（字段名 => 中文标签）
    $allowed_fields = [
        'zhupin' => '主频频率',
        'gonghao' => '功耗',
        'hexin' => '核心数量',
        'xiancheng' => '线程数量',
        'units' => '流处理器数量',
        'xiancun' => '显存大小',

    ];
    

    $parts = [];
    foreach ($differences as $field_name => $percentage) {
        // 只处理预设的字段
        if (!array_key_exists($field_name, $allowed_fields)) {
            continue;
        }
        
        $label = $allowed_fields[$field_name];
        $unit = $field_units[$field_name] ?? '';
        
        $formatted = ($percentage >= 0 ? "领先" : "落后") . abs($percentage) . "%";
        $parts[] = $label . $formatted . ($unit ? "({$unit})" : "");
    }
    
    if (empty($parts)) {
        return "{$product1_name}和{$product2_name}没有可比较的数值参数";
    }
    
    return "{$product1_name} 对比 {$product2_name} 在" . implode('，', $parts);
}