<?php
/**
 * Fired when the plugin is uninstalled.
 * Removes options and custom database table.
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// Delete plugin options
delete_option( 'ccp_options' );
delete_option( 'ccp_db_version' );

// Drop custom database table
global $wpdb;
$table_name = $wpdb->prefix . 'comparisons';
$wpdb->query( "DROP TABLE IF EXISTS {$table_name}" );

// Optional: Maybe remove rewrite rules? Flushing on deactivation is usually sufficient.
// flush_rewrite_rules(); // Be cautious with this in uninstall.php

?>