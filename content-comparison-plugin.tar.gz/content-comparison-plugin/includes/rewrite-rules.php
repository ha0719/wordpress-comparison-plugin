<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Register custom rewrite rules for the comparison page.
 * URL structure: /compare/{slug1}-vs-{slug2}/
 */
function ccp_register_rewrite_rules() {
    add_rewrite_rule(
        '^([^/]+)-vs-([^/]+)/?$',  // 移除了前面的compare/
        'index.php?comparison_slugs=$matches[1]-vs-$matches[2]',
        'top'
    );
}

/**
 * Register custom query variables.
 *
 * @param array $vars The array of existing query variables.
 * @return array The modified array of query variables.
 */
function ccp_register_query_vars( $vars ) {
    $vars[] = 'comparison_slugs'; // Stores "slug1-vs-slug2"
    return $vars;
}