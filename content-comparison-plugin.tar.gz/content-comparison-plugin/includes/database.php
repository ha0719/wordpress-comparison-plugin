<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Creates the custom database table for storing comparisons.
 */
function ccp_create_comparison_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'comparisons';
    $charset_collate = $wpdb->get_charset_collate();

    // Check if table exists and its version
    $current_db_version = get_option( 'ccp_db_version', '0' );

    if ( version_compare( $current_db_version, CCP_DB_VERSION, '<' ) ) {
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            post_type varchar(20) NOT NULL,
            item1_id bigint(20) UNSIGNED NOT NULL,
            item2_id bigint(20) UNSIGNED NOT NULL,
            comparison_pair varchar(50) NOT NULL, -- Stores sorted IDs like '123_456'
            count mediumint(9) NOT NULL DEFAULT 1,
            last_compared datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY unique_comparison (post_type, comparison_pair),
            KEY item1_id (item1_id),
            KEY item2_id (item2_id),
            KEY post_type (post_type)
        ) $charset_collate;";

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql );

        update_option( 'ccp_db_version', CCP_DB_VERSION );
    }
}

/**
 * Saves or updates a comparison record.
 * Ensures A vs B and B vs A are treated as the same comparison.
 *
 * @param int    $item1_id  ID of the first item.
 * @param int    $item2_id  ID of the second item.
 * @param string $post_type Post type slug.
 */
function ccp_save_comparison( $item1_id, $item2_id, $post_type ) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'comparisons';

    // Sanitize inputs
    $item1_id = absint( $item1_id );
    $item2_id = absint( $item2_id );
    $post_type = sanitize_key( $post_type ); // Use sanitize_key for post type slug

    if ( ! $item1_id || ! $item2_id || ! $post_type || $item1_id === $item2_id ) {
        return false; // Invalid data
    }

    // Ensure consistent pairing (lower ID first)
    $ids = array( $item1_id, $item2_id );
    sort( $ids, SORT_NUMERIC );
    $comparison_pair = $ids[0] . '_' . $ids[1];

    // Check if this pair already exists for this post type
    $existing = $wpdb->get_row( $wpdb->prepare(
        "SELECT id, count FROM $table_name WHERE post_type = %s AND comparison_pair = %s",
        $post_type,
        $comparison_pair
    ) );

    $current_time = current_time( 'mysql' );

    if ( $existing ) {
        // Update existing record
        $wpdb->update(
            $table_name,
            array(
                'count' => $existing->count + 1,
                'last_compared' => $current_time,
            ),
            array( 'id' => $existing->id ),
            array( '%d', '%s' ), // Format for count and last_compared
            array( '%d' )        // Format for WHERE clause (id)
        );
    } else {
        // Insert new record
        $wpdb->insert(
            $table_name,
            array(
                'post_type'       => $post_type,
                'item1_id'        => $ids[0], // Store sorted IDs
                'item2_id'        => $ids[1],
                'comparison_pair' => $comparison_pair,
                'count'           => 1,
                'last_compared'   => $current_time,
            ),
            array( '%s', '%d', '%d', '%s', '%d', '%s' ) // Data formats
        );
    }

    return true;
}

/**
 * Retrieves recent or popular comparisons.
 *
 * @param string $type      'recent' or 'popular'.
 * @param int    $limit     Number of results to return.
 * @param string $post_type Optional. Filter by post type slug.
 * @return array|object|null Database query results.
 */
function ccp_get_comparisons( $type = 'recent', $limit = 5, $post_type = '' ) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'comparisons';
    $limit = absint( $limit );
    if ($limit <= 0) $limit = 5;

    $where_clause = '';
    $prepare_args = array();

    if ( !empty($post_type) ) {
        $where_clause = "WHERE post_type = %s";
        $prepare_args[] = sanitize_key($post_type);
    }

    $order_by = ($type === 'popular') ? 'count DESC' : 'last_compared DESC';

    $prepare_args[] = $limit; // Add limit to prepare args

    $sql = $wpdb->prepare(
        "SELECT * FROM $table_name $where_clause ORDER BY $order_by LIMIT %d",
        $prepare_args // Pass all args here
    );

    $results = $wpdb->get_results( $sql );

    return $results;
}