<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Get all registered post types (publicly queryable).
 *
 * @return array Associative array of post type objects.
 */
function ccp_get_all_post_types() {
    $args = array(
       'public'   => true,
       // '_builtin' => false // Uncomment to exclude built-in types like post/page initially
    );
    $post_types = get_post_types( $args, 'objects' );
    return $post_types;
}

/**
 * Get all registered meta keys for a specific post type.
 * This is an approximation, might not get *all* keys if some posts don't have them.
 * A more robust solution might involve ACF integration or manual registration.
 *
 * @param string $post_type The post type slug.
 * @param int    $limit     Number of posts to sample for meta keys.
 * @return array Array of unique meta key names.
 */
function ccp_get_post_type_meta_keys( $post_type, $limit = 10 ) {
    $meta_keys = array();
    $args = array(
        'post_type' => $post_type,
        'posts_per_page' => $limit,
        'post_status' => 'any', // Include drafts etc. to find keys
        'fields' => 'ids', // Only get IDs for performance
    );
    $posts = get_posts($args);

    if ($posts) {
        foreach ($posts as $post_id) {
            $post_meta = get_post_meta($post_id);
            if ($post_meta) {
                $meta_keys = array_merge($meta_keys, array_keys($post_meta));
            }
        }
    }

    // Filter out internal keys (starting with _)
    $filtered_keys = array_filter(array_unique($meta_keys), function($key) {
        return substr($key, 0, 1) !== '_';
    });

    sort($filtered_keys);
    return $filtered_keys;
}

/**
 * Get the slug to use for comparison URLs.
 * Prioritizes the custom slug field from settings, falls back to post_name.
 *
 * @param WP_Post $post The post object.
 * @return string The slug.
 */
function ccp_get_comparison_slug( $post ) {
    if ( ! $post instanceof WP_Post ) {
        return '';
    }

    $options = get_option( 'ccp_options' );
    $custom_slug_field = isset( $options['slug_field'] ) ? sanitize_text_field( $options['slug_field'] ) : '';
    $custom_slug_value = '';

    if ( ! empty( $custom_slug_field ) ) {
        $custom_slug_value = get_post_meta( $post->ID, $custom_slug_field, true );
    }

    // Use custom slug if available and not empty, otherwise use post_name (the default slug)
    // Sanitize the final slug to be URL-friendly
    $slug = ! empty( $custom_slug_value ) ? sanitize_title( $custom_slug_value ) : $post->post_name;

    // Fallback if everything else fails (should not happen with published posts)
    if ( empty( $slug ) ) {
        $slug = sanitize_title( $post->post_title );
    }
     if ( empty( $slug ) ) {
        $slug = $post->ID; // Absolute fallback
    }


    return $slug;
}

/**
 * Get a post object by its comparison slug.
 * Tries matching the custom slug field first, then the default post_name.
 *
 * @param string $slug      The slug to search for.
 * @param string $post_type The post type to search within.
 * @return WP_Post|null The found post object or null.
 */
function ccp_get_post_by_comparison_slug( $slug, $post_type ) {
    $options = get_option( 'ccp_options' );
    $custom_slug_field = isset( $options['slug_field'] ) ? sanitize_text_field( $options['slug_field'] ) : '';
    $post = null;

    // 1. Try matching the custom meta field value
    if ( ! empty( $custom_slug_field ) ) {
        $args = array(
            'post_type' => $post_type,
            'post_status' => 'publish',
            'posts_per_page' => 1,
            'meta_query' => array(
                array(
                    'key' => $custom_slug_field,
                    'value' => $slug, // Assuming the meta value matches the sanitized slug
                    'compare' => '=',
                ),
            ),
            'fields' => 'ids', // Get only ID first for performance
        );
        $posts = get_posts( $args );
        if ( ! empty( $posts ) ) {
            $post = get_post( $posts[0] );
        }
    }

    // 2. If not found via custom field, try matching the default post_name (slug)
    if ( ! $post ) {
         $args = array(
            'name'           => $slug, // Use 'name' for post_name matching
            'post_type'      => $post_type,
            'post_status'    => 'publish',
            'posts_per_page' => 1,
            'fields'         => 'ids',
        );
        $posts = get_posts( $args );
         if ( ! empty( $posts ) ) {
            $post = get_post( $posts[0] );
        }
    }

    // 3. Absolute fallback: if slug looks like an ID, try finding by ID
    if ( ! $post && is_numeric( $slug ) ) {
        $potential_post = get_post( intval( $slug ) );
        if ( $potential_post && $potential_post->post_type === $post_type && $potential_post->post_status === 'publish' ) {
             $post = $potential_post;
        }
    }


    return $post;
}

/**
 * Get the label for a meta key (e.g., from ACF).
 * Placeholder: Implement ACF integration here if needed.
 *
 * @param string $meta_key The meta key.
 * @param string $post_type The post type.
 * @return string The display label.
 */
function ccp_get_field_label( $meta_key, $post_type ) {
    // Basic implementation: Convert key to title case
    $label = str_replace( '_', ' ', $meta_key );
    $label = ucwords( $label );

    // TODO: Add ACF integration if ACF is active
    // if ( class_exists('ACF') ) {
    //    // Try to get ACF field label - requires knowing the field key or finding it
    // }

    return apply_filters( 'ccp_field_label', $label, $meta_key, $post_type );
}