<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Handles AJAX requests for searching posts for the comparison selector.
 */
function ccp_ajax_search_posts() {
    // Verify nonce
    check_ajax_referer( 'ccp_search_nonce', 'nonce' );

    // Sanitize inputs
    $search_term = isset( $_POST['term'] ) ? sanitize_text_field( wp_unslash( $_POST['term'] ) ) : '';
    $post_type = isset( $_POST['post_type'] ) ? sanitize_key( $_POST['post_type'] ) : 'post'; // Default to 'post' if not provided

    if ( strlen( $search_term ) < 2 ) {
        wp_send_json_error( __( 'Search term must be at least 2 characters long.', 'content-comparison-plugin' ) );
        wp_die();
    }

    // Check if post type is enabled for comparison
    $options = get_option( 'ccp_options' );
    $enabled_post_types = isset($options['enabled_post_types']) ? $options['enabled_post_types'] : array();
    if ( !isset($enabled_post_types[$post_type]) || $enabled_post_types[$post_type] !== '1' ) {
        wp_send_json_error( __( 'Comparisons are not enabled for this content type.', 'content-comparison-plugin' ) );
        wp_die();
    }

    // Query posts
    $args = array(
        'post_type'      => $post_type,
        'post_status'    => 'publish',
        'posts_per_page' => 10, // Limit results
        's'              => $search_term,
    );
    $query = new WP_Query( $args );

    $results = array();
    if ( $query->have_posts() ) {
        while ( $query->have_posts() ) {
            $query->the_post();
            $results[] = array(
                'id'    => get_the_ID(),
                'label' => get_the_title(), // 'label' is used by jQuery UI Autocomplete
                'value' => get_the_title(), // 'value' is used by jQuery UI Autocomplete
                'slug'  => ccp_get_comparison_slug( get_post() ) // Include slug for URL generation
            );
        }
        wp_reset_postdata();
    }

    wp_send_json( $results ); // Send JSON response (jQuery UI Autocomplete expects this format)
    wp_die(); // this is required to terminate immediately and return a proper response
}