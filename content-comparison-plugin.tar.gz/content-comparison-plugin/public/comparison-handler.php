<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Handles the template redirect for the comparison page.
 * Checks if the query var 'comparison_slugs' is set and loads the template.
 *
 * @param string $template The path to the template file.
 * @return string The path to the template file.
 */
function ccp_template_include( $template ) {
    // Check if our query var is set.
    if ( get_query_var( 'comparison_slugs' ) ) {

        // Look for template in theme/child theme first
        $theme_template = locate_template( array( 'single-comparison.php' ) );

        if ( $theme_template ) {
            return $theme_template;
        } else {
            // Fallback to plugin's template
            $plugin_template = CCP_PLUGIN_DIR . 'public/templates/single-comparison.php';
            if ( file_exists( $plugin_template ) ) {
                return $plugin_template;
            }
        }
    }
    // Return the original template if not our comparison page.
    return $template;
}

/**
 * Prepares data for the comparison template.
 * This function can be called from within the single-comparison.php template.
 *
 * @return array|false An array containing comparison data or false on failure.
 */
function ccp_get_comparison_data() {
    $comparison_slugs_str = get_query_var('comparison_slugs');

    if (empty($comparison_slugs_str)) {
        return false;
    }

    // Split the slugs string "slug1-vs-slug2"
    $slug_parts = explode('-vs-', $comparison_slugs_str);
    if (count($slug_parts) !== 2) {
        return false; // Invalid format
    }

    $slug1 = sanitize_title($slug_parts[0]);
    $slug2 = sanitize_title($slug_parts[1]);

    if (empty($slug1) || empty($slug2) || $slug1 === $slug2) {
        return false; // Invalid slugs
    }

    $options = get_option('ccp_options');
    $enabled_post_types = isset($options['enabled_post_types']) ? array_keys($options['enabled_post_types']) : array();
    $comparable_fields_config = isset($options['comparable_fields']) ? $options['comparable_fields'] : array();

    $post1 = null;
    $post2 = null;
    $found_post_type = null;

    // Try finding the first post
    foreach ($enabled_post_types as $pt) {
        $post1 = ccp_get_post_by_comparison_slug($slug1, $pt);
        if ($post1) {
            // Now try finding the second post *of the same type*
            $post2 = ccp_get_post_by_comparison_slug($slug2, $pt);
            if ($post2) {
                $found_post_type = $pt;
                break;
            } else {
                // Found post1 but not post2 in this type, reset post1 and keep searching other types
                $post1 = null;
            }
        }
    }

    if (!$post1 || !$post2 || !$found_post_type) {
        return false;
    }

    // Check if fields are configured for this post type
    if (!isset($comparable_fields_config[$found_post_type]) || empty($comparable_fields_config[$found_post_type])) {
        return false;
    }

    // Sort fields by order value before processing
    $sorted_fields = $comparable_fields_config[$found_post_type];
    uasort($sorted_fields, function($a, $b) {
        return ($a['order'] ?? 999) <=> ($b['order'] ?? 999);
    });
    $comparable_fields = array_keys($sorted_fields);

    // --- Data Retrieval ---
    $data = array(
        'post1' => $post1,
        'post2' => $post2,
        'post_type' => $found_post_type,
        'fields' => array(),
        'schema' => null
    );

    $post1_meta = get_post_meta($post1->ID);
    $post2_meta = get_post_meta($post2->ID);
    

    // Process fields in sorted order
    foreach ($comparable_fields as $field_key) {
    if (!isset($sorted_fields[$field_key]['enabled'])) {
        continue;
    }

    // 获取ACF中文标签
    $field_label = '';
    if (function_exists('acf_get_field')) {
        $acf_field = acf_get_field($field_key);
        if ($acf_field && isset($acf_field['label'])) {
            $field_label = $acf_field['label'];
            
            // 特殊处理：翻译选择字段的选项值
            if ($acf_field['type'] === 'select' || $acf_field['type'] === 'radio') {
                $value1_translated = $this->translate_acf_value($post1_meta[$field_key][0] ?? '', $acf_field);
                $value2_translated = $this->translate_acf_value($post2_meta[$field_key][0] ?? '', $acf_field);
            }
        }
    }
    
    // 回退到默认标签
    if (empty($field_label)) {
        $field_label = ccp_get_field_label($field_key, $found_post_type);
    }

    // 获取单位信息
    $unit = $sorted_fields[$field_key]['unit'] ?? '';

    $data['fields'][$field_key] = array(
        'label' => $field_label,
        'value1' => $value1_translated ?? ($post1_meta[$field_key][0] ?? 'N/A'),
        'value2' => $value2_translated ?? ($post2_meta[$field_key][0] ?? 'N/A'),
        'order' => $sorted_fields[$field_key]['order'] ?? 999,
        'unit' => $unit // 添加单位信息
    );
}

    // --- Record the comparison ---
    ccp_save_comparison($post1->ID, $post2->ID, $found_post_type);

    // --- Generate Schema.org JSON-LD ---
    $schema_data = array(
        '@context' => 'https://schema.org',
        '@type' => 'Product',
        'name' => sprintf(__('%s vs %s Comparison', 'content-comparison-plugin'), $post1->post_title, $post2->post_title),
        'description' => sprintf(__('Side-by-side comparison of %s and %s.', 'content-comparison-plugin'), $post1->post_title, $post2->post_title),
        'model' => array(
            array(
                '@type' => 'ProductModel',
                'name' => $post1->post_title,
                'url' => get_permalink($post1->ID)
            ),
            array(
                '@type' => 'ProductModel',
                'name' => $post2->post_title,
                'url' => get_permalink($post2->ID)
            )
        )
    );

    $data['schema'] = json_encode($schema_data, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

    return $data;
}