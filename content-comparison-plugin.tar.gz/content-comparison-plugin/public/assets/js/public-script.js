jQuery(document).ready(function($) {

    // --- Autocomplete Functionality ---
    // Ensure ccp_ajax object is available
    if (typeof ccp_ajax === 'undefined') {
        console.error('CCP Error: AJAX object not localized.');
        return;
    }

    // Attach autocomplete to all input fields with the class
    $('.ccp-compare-input').each(function() {
        var $inputField = $(this);
        var $idField = $inputField.siblings('.ccp-item-id');
        var $slugField = $inputField.siblings('.ccp-item-slug');
        var $container = $inputField.closest('.ccp-selector-container');
        var postType = $container.data('post-type');
        var $messageArea = $container.find('.ccp-message-area');

        $inputField.autocomplete({
            source: function(request, response) {
                // Basic check - ensure term is long enough
                 if (request.term.length < 2) {
                    // response([]); // Return empty array immediately
                    return; // Or just return to avoid AJAX call
                }

                $.ajax({
                    url: ccp_ajax.ajax_url,
                    dataType: "json",
                    method: 'POST',
                    data: {
                        action: 'ccp_search_posts',
                        nonce: ccp_ajax.nonce,
                        term: request.term,
                        post_type: postType
                    },
                    success: function(data) {
                        if (data && typeof data === 'object') { // Check if data is an object (could be array or error object)
                            if (Array.isArray(data)) { // Success returns an array
                                response(data);
                            } else if (data.success === false && data.data) { // Handle wp_send_json_error
                                $messageArea.text(data.data).addClass('ccp-error').show();
                                console.error('CCP Search Error:', data.data);
                                response([]); // Provide empty response to autocomplete
                            } else {
                                response([]); // Handle unexpected non-array success data
                            }
                        } else {
                             console.error('CCP Search Error: Invalid response format.');
                             $messageArea.text(ccp_ajax.texts.error).addClass('ccp-error').show();
                             response([]);
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.error('CCP AJAX Error:', textStatus, errorThrown);
                        $messageArea.text(ccp_ajax.texts.error).addClass('ccp-error').show();
                        response([]); // Provide empty response on error
                    }
                });
            },
            minLength: 2, // Minimum characters before searching
            select: function(event, ui) {
                // When an item is selected from the dropdown
                $inputField.val(ui.item.label); // Update the input field text
                $idField.val(ui.item.id);     // Update the hidden ID field
                $slugField.val(ui.item.slug); // Update the hidden slug field
                $messageArea.hide().removeClass('ccp-error ccp-success'); // Clear any previous messages
                return false; // Prevent the default behavior (value insertion)
            },
            open: function() {
                // Optional: Add custom class to the dropdown for styling
                $(this).autocomplete("widget").addClass("ccp-autocomplete-dropdown");
                $messageArea.hide().removeClass('ccp-error ccp-success'); // Clear message when dropdown opens
            },
            close: function() {
                // Optional: Remove custom class when dropdown closes
                // $(this).autocomplete("widget").removeClass("ccp-autocomplete-dropdown");
            },
             // Optional: Handle focus event if needed
            // focus: function( event, ui ) {
            //    $inputField.val( ui.item.label );
            //     return false;
            // }

        }).on('input', function() {
            // Clear hidden fields if the user manually clears the input
             if ($(this).val().trim() === '') {
                 $idField.val('');
                 $slugField.val('');
             }
        });

        // Clear message area when user starts typing again
        $inputField.on('keyup', function() {
             if ($messageArea.is(':visible')) {
                 $messageArea.hide().removeClass('ccp-error ccp-success');
             }
        });
    });


    // --- Form Submission Handling ---
    $('.ccp-selector-form').on('submit', function(e) {
        e.preventDefault(); // Prevent default form submission

        var $form = $(this);
        var $container = $form.closest('.ccp-selector-container');
        var $messageArea = $container.find('.ccp-message-area');

        // Get selected item slugs
        var slug1 = $form.find('input[name="ccp_item1_slug"]').val();
        var slug2 = $form.find('input[name="ccp_item2_slug"]').val();
         var id1 = $form.find('input[name="ccp_item1_id"]').val();
         var id2 = $form.find('input[name="ccp_item2_id"]').val();

        // Basic validation
        if (!slug1 || !slug2 || !id1 || !id2) {
            $messageArea.text(ccp_ajax.texts.select_two).addClass('ccp-error').show();
            return; // Stop submission
        }
         if (id1 === id2) {
            $messageArea.text(ccp_ajax.texts.select_different).addClass('ccp-error').show(); // Add this text in PHP localize
            return;
        }


        // Construct the comparison URL: /compare/{slug1}-vs-{slug2}/
        // Ensure slugs are URL-safe (though they should be from the AJAX response)
        var urlSlug1 = encodeURIComponent(slug1);
        var urlSlug2 = encodeURIComponent(slug2);
        var comparisonUrl = ccp_ajax.compare_base_url + urlSlug1 + '-vs-' + urlSlug2 + '/';

        // Redirect the user
        window.location.href = comparisonUrl;
    });

});