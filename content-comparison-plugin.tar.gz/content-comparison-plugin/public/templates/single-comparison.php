<?php
/**
 * Template for displaying the comparison page.
 *
 * This template can be overridden by copying it to yourtheme/single-comparison.php.
 *
 * Available variables:
 * $comparison_data : Array containing 'post1', 'post2', 'post_type', 'fields', 'schema'.
 * Or false if data retrieval failed.
 */

// Fetch the comparison data using the helper function
$comparison_data = ccp_get_comparison_data();

/**
 * Header template for the theme
 *
 * Displays all of the <head> section and everything up till <div id="main">.
 *
 * @package WordPress
 * @subpackage Twenty_Eleven
 * @since Twenty Eleven 1.0
 */
?>
<!DOCTYPE html>
<!--[if IE 6]>
<html id="ie6" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 7]>
<html id="ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html id="ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 6) & !(IE 7) & !(IE 8)]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>
<?php
	// Print the <title> tag based on what is being viewed.
	global $page, $paged;

	wp_title( '|', true, 'right' );

	// Add the site name.
	bloginfo( 'name' );

	// Add the site description for the home/front page.
	$site_description = get_bloginfo( 'description', 'display' );
if ( $site_description && ( is_home() || is_front_page() ) ) {
	echo " | $site_description";
}

	// Add a page number if necessary:
if ( ( $paged >= 2 || $page >= 2 ) && ! is_404() ) {
	/* translators: %s: Page number. */
	echo esc_html( ' | ' . sprintf( __( 'Page %s', 'twentyeleven' ), max( $paged, $page ) ) );
}

?>
	</title>
<link rel="profile" href="https://gmpg.org/xfn/11" />
<link rel="stylesheet" type="text/css" media="all" href="<?php echo esc_url( get_stylesheet_uri() ); ?>?ver=20250415" />
<link rel="pingback" href="<?php echo esc_url( get_bloginfo( 'pingback_url' ) ); ?>">
<!--[if lt IE 9]>
<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/html5.js?ver=3.7.0" type="text/javascript"></script>
<![endif]-->
<?php
	/*
	 * We add some JavaScript to pages with the comment form
	 * to support sites with threaded comments (when in use).
	 */
if ( is_singular() && get_option( 'thread_comments' ) ) {
	wp_enqueue_script( 'comment-reply' );
}

	/*
	 * Always have wp_head() just before the closing </head>
	 * tag of your theme, or you will break many plugins, which
	 * generally use this hook to add elements to <head> such
	 * as styles, scripts, and meta tags.
	 */
	wp_head();
?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="hfeed">
	<header id="branding">
			<hgroup> 
    <h3 id="site-title">
        <span>
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" <?php echo $is_front ? 'aria-current="page"' : ''; ?>>
                <?php bloginfo( 'name' ); ?>
            </a>
        </span>
    </h3>

    <h4 id="site-description">
        <?php bloginfo( 'description' ); ?>
    </h4>
</hgroup>


			<?php
				// Check to see if the header image has been removed.
				$header_image = get_header_image();
			if ( $header_image ) :
				// Compatibility with versions of WordPress prior to 3.4.
				if ( function_exists( 'get_custom_header' ) ) {
					/*
					 * We need to figure out what the minimum width should be for our featured image.
					 * This result would be the suggested width if the theme were to implement flexible widths.
					 */
					$header_image_width = get_theme_support( 'custom-header', 'width' );
				} else {
					$header_image_width = HEADER_IMAGE_WIDTH;
				}
				?>
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" <?php echo $is_front ? 'aria-current="page"' : ''; ?>>
				<?php
				/*
				 * The header image.
				 * Check if this is a post or page, if it has a thumbnail, and if it's a big one
				 */
				$image = false;
				if ( is_singular() && has_post_thumbnail( $post->ID ) ) {
					$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), array( $header_image_width, $header_image_width ) );
				}
				if ( $image && $image[1] >= $header_image_width ) {
					// Houston, we have a new header image!
					echo get_the_post_thumbnail( $post->ID, 'post-thumbnail' );
				} else {
					twentyeleven_header_image();
				} // End check for featured image or standard header.
				?>
			</a>
			<?php endif; // End check for removed header image. ?>

			<?php
				// Has the text been hidden?
			if ( 'blank' === get_header_textcolor() ) :
				$header_image_class = '';
				if ( $header_image ) {
					$header_image_class = ' with-image';
				}
				?>
			<div class="only-search<?php echo $header_image_class; ?>">
				<?php get_search_form(); ?>
			</div>
				<?php
				else :
					?>
					<?php get_search_form(); ?>
			<?php endif; ?>

			<nav id="access">
				<h3 class="assistive-text"><?php _e( 'Main menu', 'twentyeleven' ); ?></h3>
				<?php
				/*
				 * Our navigation menu. If one isn't filled out, wp_nav_menu() falls back to wp_page_menu().
				 * The menu assigned to the primary location is the one used.
				 * If one isn't assigned, the menu with the lowest ID is used.
				 */
				wp_nav_menu( array( 'theme_location' => 'primary' ) );
				?>
			</nav><!-- #access -->
	</header><!-- #branding -->


	<div id="main">

<div id="primary" class="content-area ccp-comparison-page">
    <main id="main" class="site-main" role="main" style="padding: 0;">

        <?php if ( $comparison_data ) : ?>
            <?php
                $post1 = $comparison_data['post1'];
                $post2 = $comparison_data['post2'];
                $fields = $comparison_data['fields'];
                $schema_json = $comparison_data['schema'];
                $post_type_object = get_post_type_object($comparison_data['post_type']);
            ?>

            <article class="ccp-comparison-article">
                <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6579450190100468"
     crossorigin="anonymous"></script>
<!-- cpu-compare -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-6579450190100468"
     data-ad-slot="7368107095"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
                <header class="entry-header ccp-comparison-header">
                    <h1 class="entry-title ccp-comparison-title" style="padding: 20px;margin-bottom: 0px;">
                        <?php printf(
                            esc_html__( '%1$s 和 %2$s 参数对比 性能差异和区别', 'content-comparison-plugin' ),
                            esc_html( $post1->post_title ),
                            esc_html( $post2->post_title ),
                            esc_html( $post_type_object->labels->singular_name )
                        ); ?>
                    </h1>
                    <!--<?php
                    // Output Schema.org JSON-LD
                    // if ($schema_json) {
                    //     echo '<script type="application/ld+json">' . $schema_json . '</script>';
                    // }
                    // ?>-->
                </header>
                <div class="entry-content ccp-comparison-content" style="padding: 20px;">
                    <h2>参与对比产品</h2>
                             <p>产品1：<a href="<?php echo esc_url(get_permalink($post1->ID)); ?>" >
                                        <?php echo esc_html( $post1->post_title ); ?> 详细参数</a>
                                 | 产品2：<a href="<?php echo esc_url(get_permalink($post2->ID)); ?>" >
                                        <?php echo esc_html( $post1->post_title ); ?> 详细参数</a></p>
                            
                    <h2>主要参数对比结论</h2>
                    <?php
// 获取产品参数（假设存储在ACF字段组'specifications'中）
$product1_params = get_fields($post1->ID);
$product2_params = get_fields($post2->ID);

// 计算数值差异
$differences = ccp_calculate_numeric_differences(
    is_array($product1_params) ? $product1_params : [],
    is_array($product2_params) ? $product2_params : []
);

// 显示对比摘要
if (!empty($differences)) : ?>
    <div class="ccp-comparison-summary" style="margin-bottom: 20px;">
        <p><?php 
            echo esc_html(
                ccp_generate_comparison_summary(
                    $post1->post_title,
                    $post2->post_title,
                    $differences
                )
            ); 
        ?></p>
        <p>因跑分数据更新频繁，表格仅对比硬件参数，常用CPU和显卡跑分数据对比和排名可以访问<a href="https://cpuranklist.com/" target="_blank">CPU天梯图</a>或<a href="https://cpuranklist.com/gpu.php" target="_blank">显卡天梯图</a>查看.</p>
    </div>
<?php endif; ?>
                    <h2>全部参数对比</h2>
                    <table class="ccp-comparison-table">
                        <thead>
                            <tr>
                                <th class="ccp-param-header" style="font-size:14px;"><?php esc_html_e( '参数', 'content-comparison-plugin' ); ?></th>
                                <th class="ccp-item-header ccp-item-1">
                                     <?php if ( has_post_thumbnail( $post1->ID ) ) : ?>
                                        <div class="ccp-item-thumbnail">
                                            <a href="<?php echo esc_url( get_permalink( $post1->ID ) ); ?>">
                                                <?php echo get_the_post_thumbnail( $post1->ID, 'thumbnail' ); ?>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                    <div class="ccp-item-title" style="font-size:14px;">
                                        <a href="<?php echo esc_url( get_permalink( $post1->ID ) ); ?>">
                                            <?php echo esc_html( $post1->post_title ); ?>
                                        </a>
                                    </div>
                                </th>
                                <th class="ccp-item-header ccp-item-2">
                                     <?php if ( has_post_thumbnail( $post2->ID ) ) : ?>
                                        <div class="ccp-item-thumbnail">
                                             <a href="<?php echo esc_url( get_permalink( $post2->ID ) ); ?>">
                                                <?php echo get_the_post_thumbnail( $post2->ID, 'thumbnail' ); ?>
                                             </a>
                                        </div>
                                    <?php endif; ?>
                                     <div class="ccp-item-title" style="font-size:14px;">
                                         <a href="<?php echo esc_url( get_permalink( $post2->ID ) ); ?>">
                                            <?php echo esc_html( $post2->post_title ); ?>
                                        </a>
                                     </div>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ( $fields as $key => $field_data ) : ?>
    <?php
    $diff_class = ($field_data['value1'] !== $field_data['value2']) ? 'ccp-differs' : '';
    $unit = isset($field_data['unit']) && $field_data['unit'] ? '('.esc_html($field_data['unit']).')' : '';
    ?>
    <tr>
        <td class="ccp-param-label" data-label="<?php esc_attr_e( 'Parameter', 'content-comparison-plugin' ); ?>">
            <?php echo esc_html( $field_data['label'] ); ?>
            <?php if ($unit) : ?>
                <span class="ccp-param-unit"><?php echo $unit; ?></span>
            <?php endif; ?>
        </td>
        <td class="ccp-item-value ccp-item-1 <?php echo $diff_class; ?>" data-label="<?php echo esc_attr( $post1->post_title ); ?>">
            <?php echo wp_kses_post( $field_data['value1'] ); ?>
        </td>
        <td class="ccp-item-value ccp-item-2 <?php echo $diff_class; ?>" data-label="<?php echo esc_attr( $post2->post_title ); ?>">
            <?php echo wp_kses_post( $field_data['value2'] ); ?>
        </td>
    </tr>
<?php endforeach; ?>
                            
                        </tbody>
                    </table>
                     <?php
                        // Maybe add links back to the original posts
                        // Or links to purchase if it's an e-commerce scenario
                    ?>
                    <p>TIPS：一般来说，在做购买决策时，优先选择预算范围内参数更高的产品，简要的选购指南可以<a href="https://cpuranklist.com/guide.php" target="_blank">点击这里</a>查看.</p>
                    <p style="margin-top: 20px;color: #999;">如果发现产品数据或功能问题可以<a href="https://docs.qq.com/sheet/DT0JLSmFVV0ptSFF6?tab=BB08J2" target="_blank" rel="nofollow">点击这里</a>进行反馈或在评论区留言,这将帮助我们做得更好.</p>
                    
                    <h2>最新对比记录</h2>
                        <?php
// 直接调用函数，传递所需的参数
echo ccp_display_recent_comparisons_shortcode( array(
    'limit' => 10, // 设置显示的最大对比数量
) );
?>
<h3 style="font-size:16px;font-weight: bold;">我来点评</h3>
		<div id="tcomment"></div>
<script src="https://s4.zstatic.net/ajax/libs/twikoo/1.6.41/twikoo.all.min.js"></script>
<script>
twikoo.init({
  envId: 'https://twikoo.cpuranklist.com/', // 腾讯云环境填 envId；Vercel 环境填地址（https://xxx.vercel.app）
  el: '#tcomment', // 容器元素
  // region: 'ap-guangzhou', // 环境地域，默认为 ap-shanghai，腾讯云环境填 ap-shanghai 或 ap-guangzhou；Vercel 环境不填
  // path: location.pathname, // 用于区分不同文章的自定义 js 路径，如果您的文章路径不是 location.pathname，需传此参数
  // lang: 'zh-CN', // 用于手动设定评论区语言，支持的语言列表 https://github.com/twikoojs/twikoo/blob/main/src/client/utils/i18n/index.js
})
</script>
                </div></article><?php else : ?>

            <article class="ccp-comparison-error">
                 <header class="entry-header">
                     <h1 class="entry-title"><?php esc_html_e( 'Comparison Not Found', 'content-comparison-plugin' ); ?></h1>
                 </header>
                 <div class="entry-content">
                    <p><?php esc_html_e( 'Sorry, we could not find the items you were looking for, or comparison is not configured correctly for this content type.', 'content-comparison-plugin' ); ?></p>
                     <p><?php
                        $home_url = home_url('/');
                        printf(
                             wp_kses(
                                 /* translators: %s: Link to home page */
                                 __( 'Please try searching again or return to the <a href="%s">homepage</a>.', 'content-comparison-plugin' ),
                                 array( 'a' => array( 'href' => array() ) )
                             ),
                             esc_url( $home_url )
                         );
                     ?></p>
                 </div>
            </article>

        <?php endif; ?>

    </main></div><?php
get_sidebar(); // Include theme sidebar (optional)
get_footer(); // Include theme footer
?>