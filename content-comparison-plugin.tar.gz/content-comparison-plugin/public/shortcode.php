<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Renders the comparison selector shortcode.
 * [compare_selector post_type="cpu"]
 * Enqueues necessary scripts and styles directly.
 *
 * @param array $atts Shortcode attributes.
 * @return string HTML output for the selector.
 */
function ccp_compare_selector_shortcode( $atts ) {
    $atts = shortcode_atts( array(
        'post_type' => '', // Required attribute
    ), $atts, 'compare_selector' );

    $post_type = sanitize_key( $atts['post_type'] );

    // --- Input Validation ---
    if ( empty( $post_type ) ) {
        // Shortcode requires post_type attribute
        if ( current_user_can('edit_posts') ) { // Show specific error to editors/admins
             return '<p class="ccp-error"><strong>' . __( 'Comparison Shortcode Error:', 'content-comparison-plugin' ) . '</strong> ' . __( 'Missing "post_type" attribute.', 'content-comparison-plugin' ) . '</p>';
        }
        return ''; // Hide error from public visitors
    }
    if ( ! post_type_exists( $post_type ) ) {
        // Specified post_type does not exist
         if ( current_user_can('edit_posts') ) {
             return '<p class="ccp-error"><strong>' . __( 'Comparison Shortcode Error:', 'content-comparison-plugin' ) . '</strong> ' . sprintf( __( 'Content type "%s" does not exist.', 'content-comparison-plugin' ), esc_html($post_type) ) . '</p>';
         }
         return '';
    }
    $options = get_option( 'ccp_options' );
    $enabled_post_types = isset( $options['enabled_post_types'] ) ? $options['enabled_post_types'] : array();
    if ( ! isset( $enabled_post_types[$post_type] ) || $enabled_post_types[$post_type] !== '1' ) {
        // Specified post_type is not enabled in plugin settings
        if ( current_user_can('edit_posts') ) {
            return '<p class="ccp-error"><strong>' . __( 'Comparison Shortcode Error:', 'content-comparison-plugin' ) . '</strong> ' . sprintf( __( 'Comparison is not enabled for content type "%s" in plugin settings.', 'content-comparison-plugin' ), esc_html($post_type) ) . '</p>';
        }
        return '';
    }
    // --- End Validation ---


    // *** Enqueue Assets required for this shortcode ***
    // WordPress handles duplicates, so calling these is safe even if called elsewhere.
    wp_enqueue_style( 'ccp-public-style' ); // Our plugin's public CSS
    wp_enqueue_style( 'jquery-ui-css' );    // Default jQuery UI theme for autocomplete styling

    // Enqueue core scripts; WP handles loading them if not already present.
    wp_enqueue_script( 'jquery' );
    wp_enqueue_script( 'jquery-ui-autocomplete' );

    // Enqueue our plugin's public JavaScript (which depends on jquery & jquery-ui-autocomplete)
    wp_enqueue_script( 'ccp-public-script' );
    // Note: wp_localize_script for 'ccp-public-script' is now handled in the main ccp_public_enqueue_scripts function


    // Get the label for the post type for user-friendly text
    $post_type_object = get_post_type_object( $post_type );
    $post_type_label_singular = $post_type_object ? $post_type_object->labels->singular_name : $post_type;
    $post_type_label_plural = $post_type_object ? $post_type_object->labels->name : $post_type;

    // Start output buffering to capture the HTML
    ob_start();
    ?>
    <div class="ccp-selector-container" data-post-type="<?php echo esc_attr( $post_type ); ?>">
        <p>TIPS: 输入关键词从下拉候选选中你要对比的产品型号，然后点击开始比较</p>
        <?php // The form action points to the base comparison URL; JS will construct the full slug-based URL ?>
        <form class="ccp-selector-form" action="<?php echo esc_url( home_url('/compare/') ); ?>" method="GET">

            <div class="ccp-selector-inputs">
                <div class="ccp-input-group">
                    <?php // Using htmlspecialchars to prevent XSS in placeholder if label contains special chars ?>
                    <label for="ccp_item1_<?php echo esc_attr($post_type); ?>"><?php printf(__('选择 %s 1', 'content-comparison-plugin'), esc_html($post_type_label_singular)); ?>:</label>
                    <input type="text" id="ccp_item1_<?php echo esc_attr($post_type); ?>" name="ccp_item1_name" class="ccp-compare-input" placeholder="<?php echo sprintf(htmlspecialchars(__('输入搜索 %s...', 'content-comparison-plugin')), esc_html($post_type_label_plural)); ?>" autocomplete="off">
                    <input type="hidden" name="ccp_item1_id" class="ccp-item-id">
                    <input type="hidden" name="ccp_item1_slug" class="ccp-item-slug">
                </div>

                <span class="ccp-vs"><?php _e('vs', 'content-comparison-plugin'); ?></span>

                <div class="ccp-input-group">
                     <label for="ccp_item2_<?php echo esc_attr($post_type); ?>"><?php printf(__('选择 %s 2', 'content-comparison-plugin'), esc_html($post_type_label_singular)); ?>:</label>
                    <input type="text" id="ccp_item2_<?php echo esc_attr($post_type); ?>" name="ccp_item2_name" class="ccp-compare-input" placeholder="<?php echo sprintf(htmlspecialchars(__('输入搜索 %s...', 'content-comparison-plugin')), esc_html($post_type_label_plural)); ?>" autocomplete="off">
                    <input type="hidden" name="ccp_item2_id" class="ccp-item-id">
                    <input type="hidden" name="ccp_item2_slug" class="ccp-item-slug">
                </div>
            </div>

            <div class="ccp-selector-button">
                <button type="submit" class="ccp-compare-button"><?php esc_html_e('开始比较', 'content-comparison-plugin'); ?></button>
            </div>
            <?php // Area for JavaScript to display messages (e.g., validation errors) ?>
            <div class="ccp-message-area" style="display: none;" aria-live="polite"></div>
        </form>
    </div>
    <?php
    // Return buffered content
    return ob_get_clean();
}