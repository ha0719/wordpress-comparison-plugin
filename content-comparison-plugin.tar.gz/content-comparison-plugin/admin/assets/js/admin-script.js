// Add any backend specific JavaScript here if needed.
// For example, you might add JS to show/hide field selections dynamically
// based on the enabled post types checkboxes without a full page reload.

jQuery(document).ready(function($) {
    // Example: Log to console to confirm script is loaded
    // console.log('CCP Admin Script Loaded');

    // Basic example: Show/hide field sections based on checkbox state
    // This requires a bit more complex handling to work perfectly on initial load
    // and might be better handled server-side on save as currently implemented.
    /*
    $('#ccp_enabled_post_types input[type="checkbox"]').on('change', function() {
        var postType = $(this).attr('name').match(/\[(.*?)\]/)[1]; // Extract post type from name attribute
        var fieldsetContainer = $('#ccp-comparable-fields-container').find('.ccp-post-type-fields[data-post-type="' + postType + '"]'); // Need to add data-post-type attribute in PHP

        if ($(this).is(':checked')) {
            // Maybe reveal or dynamically load fields via AJAX?
            // console.log('Enabled:', postType);
            // fieldsetContainer.show(); // Example: Show if pre-rendered
        } else {
            // console.log('Disabled:', postType);
            // fieldsetContainer.hide(); // Example: Hide if pre-rendered
        }
    });
    */
});