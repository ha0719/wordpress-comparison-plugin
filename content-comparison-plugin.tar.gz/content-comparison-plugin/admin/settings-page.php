<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Add options page to the settings menu.
 */
function ccp_add_admin_menu() {
    add_options_page(
        __( 'Content Comparison Settings', 'content-comparison-plugin' ),
        __( 'Content Comparison', 'content-comparison-plugin' ),
        'manage_options', // Capability required
        'content-comparison-settings', // Menu slug
        'ccp_settings_page_html' // Callback function to render the page
    );
}

/**
 * Initialize settings, sections, and fields.
 */
function ccp_settings_init() {
    // Register the main setting group
    register_setting( 'ccp_settings_group', 'ccp_options', 'ccp_options_sanitize' );

    // Section: General Settings
    add_settings_section(
        'ccp_general_section', // ID
        __( 'General Settings', 'content-comparison-plugin' ), // Title
        'ccp_general_section_callback', // Callback
        'content-comparison-settings' // Page slug
    );

    add_settings_field(
        'ccp_field_enabled_post_types', // ID
        __( 'Enable Comparison For', 'content-comparison-plugin' ), // Title
        'ccp_enabled_post_types_render', // Callback function to render the field
        'content-comparison-settings', // Page slug
        'ccp_general_section', // Section ID
        array( 'label_for' => 'ccp_enabled_post_types' ) // Add label association (optional)
    );

     add_settings_field(
        'ccp_field_slug_field',
        __( 'Custom URL Slug Field (Meta Key)', 'content-comparison-plugin' ),
        'ccp_slug_field_render',
        'content-comparison-settings',
        'ccp_general_section',
        array( 'label_for' => 'ccp_slug_field' )
    );


    // Section: Comparable Fields (Dynamically generated based on enabled post types)
    add_settings_section(
        'ccp_fields_section',
        __( 'Comparable Fields per Content Type', 'content-comparison-plugin' ),
        'ccp_fields_section_callback',
        'content-comparison-settings'
    );

    // Fields for this section are added dynamically in the settings page HTML callback
}

/**
 * Callback for the General Settings section description.
 */
function ccp_general_section_callback() {
    echo '<p>' . __( 'Select the content types you want to enable comparison for and configure global settings.', 'content-comparison-plugin' ) . '</p>';
}

/**
 * Render the checkboxes for enabling post types.
 */
function ccp_enabled_post_types_render() {
    $options = get_option( 'ccp_options' );
    $enabled_post_types = isset( $options['enabled_post_types'] ) ? $options['enabled_post_types'] : array();
    $all_post_types = ccp_get_all_post_types();

    if ( empty( $all_post_types ) ) {
        echo '<p>' . __( 'No public post types found.', 'content-comparison-plugin' ) . '</p>';
        return;
    }

    echo '<fieldset id="ccp_enabled_post_types">';
    foreach ( $all_post_types as $post_type => $pt_object ) {
        $checked = isset( $enabled_post_types[$post_type] ) && $enabled_post_types[$post_type] === '1' ? 'checked' : '';
        printf(
            '<label style="margin-right: 15px; display: inline-block;"><input type="checkbox" name="ccp_options[enabled_post_types][%s]" value="1" %s> %s (%s)</label><br>',
            esc_attr( $post_type ),
            $checked,
            esc_html( $pt_object->labels->name ), // Plural name
            esc_html( $post_type ) // Slug
        );
    }
    echo '</fieldset>';
     echo '<p class="description">' . __('Check the boxes for the content types where you want to enable the comparison feature.', 'content-comparison-plugin') . '</p>';
}

/**
 * Render the input field for the custom slug meta key.
 */
function ccp_slug_field_render() {
    $options = get_option('ccp_options');
    $slug_field = isset($options['slug_field']) ? $options['slug_field'] : '';
    printf(
        '<input type="text" id="ccp_slug_field" name="ccp_options[slug_field]" value="%s" class="regular-text" />',
        esc_attr($slug_field)
    );
    echo '<p class="description">' . __('Optional. Enter the meta key name that stores a custom, unique value (like a short name or product code) to be used in the comparison URL slug. If empty, the default post slug (post name) will be used.', 'content-comparison-plugin') . '</p>';
     echo '<p class="description">' . __('Example: <code>product_short_name</code> or <code>model_slug</code>.', 'content-comparison-plugin') . '</p>';
}


/**
 * Callback for the Comparable Fields section description.
 */
function ccp_fields_section_callback() {
     echo '<p>' . __( 'For each enabled content type, select the specific fields (meta keys) that should be displayed in the comparison table.', 'content-comparison-plugin' ) . '</p>';
}

/**
 * Render the main settings page HTML structure.
 */
function ccp_settings_page_html() {
    // Check user capabilities
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    ?>
    <div class="wrap ccp-settings-wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        <form action="options.php" method="post">
            <?php
            // Output security fields for the registered setting "ccp_settings_group"
            settings_fields( 'ccp_settings_group' );

            // Output setting sections and fields for the page "content-comparison-settings"
            // do_settings_sections( 'content-comparison-settings' ); // Default WP way

            // --- Custom rendering to handle dynamic fields ---
            ?>
            <h2><?php _e( 'General Settings', 'content-comparison-plugin' ); ?></h2>
            <?php ccp_general_section_callback(); ?>
            <table class="form-table" role="presentation">
                <tbody>
                    <tr>
                        <th scope="row">
                            <label for="ccp_enabled_post_types"><?php _e( 'Enable Comparison For', 'content-comparison-plugin' ); ?></label>
                        </th>
                        <td>
                            <?php ccp_enabled_post_types_render(); ?>
                        </td>
                    </tr>
                     <tr>
                        <th scope="row">
                            <label for="ccp_slug_field"><?php _e( 'Custom URL Slug Field', 'content-comparison-plugin' ); ?></label>
                        </th>
                        <td>
                            <?php ccp_slug_field_render(); ?>
                        </td>
                    </tr>
                </tbody>
            </table>

            <hr>

             <h2><?php _e( 'Comparable Fields per Content Type', 'content-comparison-plugin' ); ?></h2>
             <?php ccp_fields_section_callback(); ?>
             <div id="ccp-comparable-fields-container">
                <?php ccp_comparable_fields_render(); // Render the dynamic fields ?>
             </div>
             <?php
            // --- End custom rendering ---

            // Output save settings button
            submit_button( __( 'Save Settings', 'content-comparison-plugin' ) );
            ?>
        </form>

         <hr>
        <h2><?php _e( 'Shortcode Usage', 'content-comparison-plugin' ); ?></h2>
        <p><?php _e( 'To display the comparison selector on a page or post, use the following shortcode:', 'content-comparison-plugin' ); ?></p>
        <p><?php _e( 'Replace <code>your_post_type</code> with the slug of the content type you want to compare (e.g., <code>cpu</code>, <code>gpu</code>, <code>post</code>). Make sure the content type is enabled above.', 'content-comparison-plugin' ); ?></p>
        <p><code>[compare_selector post_type="your_post_type"]</code></p>
        <p><?php _e('Example:', 'content-comparison-plugin'); ?> <code>[compare_selector post_type="cpu"]</code></p>

        <h2><?php _e( 'Comparison History Shortcodes', 'content-comparison-plugin' ); ?></h2>
        <p><?php _e( 'Display recent or popular comparisons:', 'content-comparison-plugin' ); ?></p>
        <ul>
            <li><strong><?php _e('Recent Comparisons:', 'content-comparison-plugin'); ?></strong> <code>[recent_comparisons limit="5" post_type="cpu"]</code> (<code>limit</code> and <code>post_type</code> are optional)</li>
            <li><strong><?php _e('Popular Comparisons:', 'content-comparison-plugin'); ?></strong> <code>[popular_comparisons limit="5" post_type="gpu"]</code> (<code>limit</code> and <code>post_type</code> are optional)</li>
        </ul>


    </div><?php
}

/**
 * Render the dynamic comparable fields section based on enabled post types.
 * This is called within the ccp_settings_page_html function.
 */
function ccp_comparable_fields_render() {
    $options = get_option('ccp_options');
    $enabled_post_types = isset($options['enabled_post_types']) ? $options['enabled_post_types'] : array();
    $comparable_fields = isset($options['comparable_fields']) ? $options['comparable_fields'] : array();
    
    foreach (ccp_get_all_post_types() as $post_type => $post_type_obj) {
        if (!isset($enabled_post_types[$post_type])) continue;
        
        echo '<div class="ccp-post-type-fields" data-post-type="'.esc_attr($post_type).'">';
        echo '<h3>'.esc_html($post_type_obj->labels->singular_name).'</h3>';
        
        $meta_keys = ccp_get_post_type_meta_keys($post_type);
        foreach ($meta_keys as $key) {
            $is_checked = isset($comparable_fields[$post_type][$key]['enabled']) ? 'checked' : '';
            $order = $comparable_fields[$post_type][$key]['order'] ?? (count($comparable_fields[$post_type] ?? []) + 1);
            $unit = $comparable_fields[$post_type][$key]['unit'] ?? '';
            
            echo '<fieldset class="ccp-field-item" data-field="'.esc_attr($key).'">';
            echo '<span class="dashicons dashicons-move"></span>';
            echo '<input type="number" class="ccp-field-order" name="ccp_options[comparable_fields]['.esc_attr($post_type).']['.esc_attr($key).'][order]" value="'.esc_attr($order).'" min="1" style="width:50px">';
            echo '<label><input type="checkbox" name="ccp_options[comparable_fields]['.esc_attr($post_type).']['.esc_attr($key).'][enabled]" '.$is_checked.'> '.esc_html($key).'</label>';
            // 添加单位输入框
            echo '<input type="text" class="ccp-field-unit" name="ccp_options[comparable_fields]['.esc_attr($post_type).']['.esc_attr($key).'][unit]" value="'.esc_attr($unit).'" placeholder="'.esc_attr__('单位', 'content-comparison-plugin').'" style="width:80px;margin-left:10px;">';
            echo '</fieldset>';
        }
        echo '</div>';
    }
    
    // 添加排序JS
    ?>
    <script>
    jQuery(document).ready(function($) {
        $('.ccp-post-type-fields').sortable({
            handle: '.dashicons-move',
            opacity: 0.7,
            update: function(event, ui) {
                $(this).find('.ccp-field-item').each(function(index) {
                    $(this).find('.ccp-field-order').val(index + 1);
                });
            }
        });
    });
    </script>
    <?php
}


/**
 * Sanitize plugin options before saving.
 *
 * @param array $input Raw input data from the form.
 * @return array Sanitized data.
 */
function ccp_options_sanitize($input) {
    $output = array();
    
    // 处理基础字段
    if (isset($input['enabled_post_types'])) {
        $output['enabled_post_types'] = array();
        foreach ($input['enabled_post_types'] as $post_type => $value) {
            $output['enabled_post_types'][sanitize_key($post_type)] = $value === '1' ? '1' : '0';
        }
    }
    
    // 处理slug字段
    if (isset($input['slug_field'])) {
        $output['slug_field'] = sanitize_text_field($input['slug_field']);
    }
    
    // 处理可比较字段（新增排序逻辑）
    if (isset($input['comparable_fields'])) {
        $output['comparable_fields'] = array();
        
        foreach ($input['comparable_fields'] as $post_type => $fields) {
            $sorted_fields = array();
            
            foreach ($fields as $key => $settings) {
                if (isset($settings['enabled'])) {
                    $sorted_fields[$key] = array(
                        'enabled' => 1,
                        'order' => isset($settings['order']) ? absint($settings['order']) : 999,
                        'unit' => isset($settings['unit']) ? sanitize_text_field($settings['unit']) : ''
                    );
                }
            }
            
            // 按order值排序
            uasort($sorted_fields, function($a, $b) {
                return $a['order'] <=> $b['order'];
            });
            
            $output['comparable_fields'][sanitize_key($post_type)] = $sorted_fields;
        }
    }
    
    return $output;
}